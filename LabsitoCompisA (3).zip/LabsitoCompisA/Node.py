class Node:
    def __init__(self, value):
        # Asingamos id del nodo
        self.id = None

        # Asingamos valor del nodo
        self.value = value

        # Asingamos nodos hijos
        self.left =  None
        self.right =None


ParentesisApertura = '('
ParentesisCerradura = ')'

LlavesApertura = '{'
LlavesCerraduras = '}'

CorchetesApertura = '['
CorchetesCerradura = ']'

# |
alternative = '|'
# •
dot = '•'
# ?
question = '?'
# *
star = '*'

suma='+'

epsilon = 'ε'
hash = '#'

operadores=[question,star,suma,alternative]




def replace_reserved_words(r: str):
    return (r
            .replace('(', 'β')
            .replace(')', 'δ')
            .replace('{', 'ζ')
            .replace('}', 'η')
            .replace('[', 'θ')
            .replace(']', 'ω')
            .replace('|', 'φ')
            )




symbols = [replace_reserved_words(chr(i)) for i in range(1, 255) if chr(i) not in operadores]
symbols += epsilon